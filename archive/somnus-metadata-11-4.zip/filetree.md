---
somnus:
  schema: "somnus://metadata/core/2.0.0"
  id: "urn:somnus:artifact:01a19a67-7c45-73e3-9028-7b15dc65cdd4"
  revision: 2
  title: "filetree.md — somnus-metadata"
  classification:
    category: "context"
    type: "index"
    role: "informative"
    scope: "component"
    tags: []
  lifecycle:
    status: "draft"
  authority:
    standing: "candidate"
    scopes:
      - target_ref: "urn:somnus:artifact:01a19a67-7c45-73e3-9028-7b15dc65cdd4"
        aspects: ["content"]
  time:
    updated_at: "2026-11-02T04:36:47+00:00"
  names:
    slug: "filetree-md-somnus-metadata"
  knowledge:
    coverage: "artifact"
    subjects: ["urn:somnus:artifact:01a19a67-7c45-73e3-9028-7b15dc65cdd4"]
  access:
    visibility: "internal"
    allowed_uses: ["archive", "search", "reason"]
  ingestion:
    disposition: "candidate"
    body_role: "narrative"
---
# filetree.md — somnus-metadata

Spatial/dependency map for the current checkout. For task routing and authority,
start with [`AGENTS.md`](AGENTS.md); this file is not normative.

```text
.
├── AGENTS.md                         # project entry packet, validation, constraints
├── SPEC.md                           # normative core 2.0.0 contract; §§20–23 CLI/MCP/conformance/versioning
├── DECISIONS.md                      # ratified rationale D1–D19
├── PLAN.md                           # evidence, completion frontier, operator setup/handoff
├── SCOPE.md                          # bounded all-file discovery repair, native-layout acceptance
├── CONTEXT.md                        # architectural relations and observed tool boundaries
├── AGENTS.v1.md                       # superseded entry file (2026-10-31); not active
├── CONTRIBUTING.md                   # contributor setup, verification gate, naming, release-age policy
├── CODEOWNERS                        # repository ownership rules
├── .codex/OPERATING.md                # adaptive composed tool/skill route; no local hook installed
├── .claude/skills/somnus-metadata-dev/SKILL.md # repository agent development skill
├── .factory/skills/somnus-metadata-dev/SKILL.md # mirrored Factory agent development skill
├── .devcontainer/devcontainer.json   # devcontainer specification
├── .github/                          # CI, release, CodeQL, wiki workflows, dependabot, issue/PR templates
├── .pre-commit-config.yaml           # pre-commit hooks (ruff, mypy, hygiene, large-file guard)
├── .importlinter                     # 6-contract architecture layer enforcement
├── .coveragerc                       # branch + statement coverage configuration (fail_under = 85)
├── workflows.md                      # supplied BB7 suggested playbook
├── docs/
│   ├── USAGE_GUIDE.md                # step-by-step operator and coding-agent usage guide
│   ├── AGENTS.appendix.md            # global AGENTS.md snippet for proactive Somnus Metadata use
│   └── references-unrelated-to-codebase/ # user-owned collaboration context, including House fable
├── README.md                         # install and quick start
├── filetree.md                       # this navigation map
├── pyproject.toml                    # stdlib-only package, `somnus` and `somnus-metadata` entry points
├── MANIFEST.in                       # minimal release contents; excludes private operator/research artifacts
├── runbooks/
│   ├── registry-recovery.md          # global registry backup, restore, conflict resolution, re-init
│   ├── host-write-incident.md        # E_HOST triggers, carrier preambles, stamp dry-run, header recovery
│   └── package-release.md            # actual PyPI release and repeatable publishing/verification route
├── Somnus Markdown Metadata Standard Research.md # original research artifact; read-only
├── archives/                         # user-owned historical bundles; root ZIP deletions pre-exist
├── .somnus-debug/
│   ├── python_doctor.yaml            # root diagnostics configuration
│   └── python_doctor.src.yaml        # src import-aware diagnostics configuration
├── src/somnus/
│   ├── cli.py                        # argparse command surface / dispatch
│   ├── mcp.py                        # stdio JSON-RPC adapter, D17
│   ├── yamlsub.py                    # restricted YAML parser / canonical serializer
│   ├── document.py                   # envelope IO / byte preservation
│   ├── regions.py                    # in-document metadata regions
│   ├── ids.py, config.py, infer.py, output.py # identity, config, header inference, diagnostics
│   ├── model/
│   │   ├── schema.py, vocab.py       # schema definitions / controlled values
│   │   ├── validate.py               # validation pipeline
│   │   ├── lifecycle.py              # lifecycle transition rules
│   │   └── jsonschema_export.py      # JSON Schema exporter (`somnus schema --json-schema`)
│   ├── carriers/                     # Markdown, comments, sidecar placement
│   ├── db/                           # SQLite schema (`schema.sql`), FTS5 search (`search.sql`, D19), `store.py`
│   ├── commands/                     # one command module per CLI operation
│   │   └── set_fields.py             # `somnus set` implementation (D16)
│   └── tui/                          # terminal UI implementation
├── tests/
│   ├── test_conformance.py           # 21 SPEC acceptance fixtures
│   ├── test_mcp.py                   # adapter protocol, schema, and call behavior
│   ├── test_term_windows.py          # Windows console/key unit tests via kernel32/msvcrt fakes
│   ├── test_*.py                     # module and CLI behavior suites
│   └── acceptance/
│       └── installed_package_acceptance.py # explicit 67-check installed-wheel acceptance (not discovered)
├── droid-wiki/                       # explanatory wiki; secondary to SPEC/DECISIONS
│   ├── background/, features/
│   ├── how-to-contribute/, overview/
│   ├── reference/, systems/
│   └── .wiki-meta.json
└── archive/                          # historical and non-normative
    ├── README.md                     # archive boundary warning
    ├── v0.1/                         # prior spec, schemas, examples, tools
    ├── v2-proposal/                  # intermediate proposal
```

## Runtime state outside source

- `$SOMNUS_HOME` (default `~/.somnus/`): `config.toml` and `somnus.db`.
- `.python_doctor/`, `.python_doctor-src/`, `.somnus-debug/runs/`, and
  `.surgeon/` are generated/ignored tooling state; not authoritative source.

## Dependency / authority spine

```text
SPEC.md + DECISIONS.md
        ↓ contract
src/somnus/model + yamlsub + carriers + document + regions + db
        ↓ composed by
commands → cli.py → optional mcp.py / TUI
        ↓ consumed and checked by
tests/test_conformance.py + module/CLI/MCP suites
```

`archive/` is excluded from the runtime spine. `droid-wiki/` explains behavior
but does not override the normative specification.
