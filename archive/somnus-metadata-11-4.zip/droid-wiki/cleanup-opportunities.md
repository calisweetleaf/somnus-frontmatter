---
somnus:
  schema: "somnus://metadata/core/2.0.0"
  id: "urn:somnus:artifact:01a19a67-799f-74a2-bfa7-ae03a1677142"
  revision: 1
  title: "Cleanup opportunities"
  classification:
    category: "engineering"
    type: "report"
    role: "informative"
    scope: "component"
    tags: []
  lifecycle:
    status: "draft"
  authority:
    standing: "candidate"
    scopes:
      - target_ref: "urn:somnus:artifact:01a19a67-799f-74a2-bfa7-ae03a1677142"
        aspects: ["content"]
  time: {}
  names:
    slug: "cleanup-opportunities"
  knowledge:
    coverage: "artifact"
    subjects: ["urn:somnus:artifact:01a19a67-799f-74a2-bfa7-ae03a1677142"]
  access:
    visibility: "internal"
    allowed_uses: ["archive", "search", "reason"]
  ingestion:
    disposition: "candidate"
    body_role: "narrative"
---
# Cleanup opportunities

This page separates resolved drift from remaining verification boundaries and optional maintenance candidates. Size and diagnostic counts are not evidence of a correctness defect.

## Spec and code drift

### Closed warning registry

D18 resolved the undefined `W_DUPLICATE_TITLE` listing by removing it from SPEC section 19.2 rather than inventing a trigger. The four warnings are `W_PREDICATE`, `W_REGION_SPACING`, `W_REGION_UNREGISTERED`, and `W_UNMANAGED`. Existing title behavior remains: `somnus stale` reports advisory rows at similarity 0.85 and `somnus new` refuses registered-title collisions at 0.9 with `E_IO` unless `--force` is used (`src/somnus/commands/stale.py`, `src/somnus/commands/new.py`). This is not an outstanding implementation task.

## TODO and FIXME markers

A whole-word search of Python files under `src/` and `tests/` finds no uppercase `TODO`, `FIXME`, `XXX`, or `HACK` markers. The lowercase inference rule `(r"task|todo", "task")` in `src/somnus/infer.py` maps file names to the `task` type and is not a note. This search is not a dead-code analysis. Historical archive notes are not active tasks.

## Large modules and long functions

The four largest Python modules hold 2,952 of 8,138 physical Python lines in `src/somnus/` (about 36%; 49 modules, excluding 187 lines across the two SQL files):

| File | Lines | Notes |
| --- | --- | --- |
| `src/somnus/model/validate.py` | 844 | Contains `consistency` (148 lines), `walk` (86), `selectors` (54), and `references` (54) |
| `src/somnus/yamlsub.py` | 759 | Restricted YAML parser and serializer; `block_scalar` is 48 lines |
| `src/somnus/db/store.py` | 748 | Registry reconciliation and derived full-text search maintenance |
| `src/somnus/model/schema.py` | 601 | Mostly declarative schema nodes, so its size is less of a concern |

The longest functions in the package, measured with `ast`:

| Function | Lines |
| --- | --- |
| `build_payload` in `src/somnus/commands/migrate.py` | 190 |
| `consistency` in `src/somnus/model/validate.py` | 148 |
| `build_parser` in `src/somnus/cli.py` | 106 |
| `walk` in `src/somnus/model/validate.py` | 86 |
| `_index_document` in `src/somnus/db/store.py` | 84 |
| `scan_markers` in `src/somnus/regions.py` | 60 |

`build_payload` maps each v0.1 field family (identity, names, time, classification, relations, locations, leftovers) in one function; splitting it per SPEC section 22 step would match the spec's structure. `consistency` runs many unrelated intra-document checks in sequence and could be split by concern (lifecycle, authority, regions, claims). `build_parser` is long because it declares every subcommand, and `src/somnus/mcp.py` reads those declarations to build its tool schemas, so keeping them in one place is deliberate. It is not a refactoring priority.

## Terminal UI and verification boundaries

- **POSIX terminal coverage exists.** `tests/test_tui.py` now has 59 tests, including real PTY raw-mode/restoration, key, failure, and save-chain checks. The separate installed-package harness covers browser/editor sessions. The earlier absence of real-terminal tests is resolved.
- **Registry-note overlay is fixed.** `capture_notes` in `src/somnus/commands/_common.py` and `NoteBuffer` in `src/somnus/tui/app.py` route notes to the status row. Long messages are clipped; complete registry diagnosis uses `somnus index`, `somnus q --conflicts`, and history.
- **Remaining boundaries.** Native Windows `msvcrt`/`ctypes` terminal paths, hosted CI, and external MCP applications were not exercised in this wiki refresh. Prior installed acceptance is recorded in `PLAN.md` and `runbooks/package-release.md`, not a fresh universal compatibility claim.
- **Older mypy compatibility remains unresolved.** A previous wiki refresh recorded two errors with mypy 1.9.0 in `src/somnus/tui/term.py:201-202`. This refresh passed 49 files using an isolated mypy 1.18.2 installation after finding the tool absent; 1.9.0 was not rerun. The declared `mypy>=1.9` range was not changed. See [Testing](how-to-contribute/testing.md).

## Documents without Somnus headers

The repository's own working documents are not Somnus-managed: `README.md`, `PLAN.md`, `AGENTS.md`, and `filetree.md` start with a plain `#` heading and no envelope. `SPEC.md`, `DECISIONS.md`, and the files in `archive/v2-proposal/` do carry headers. Stamping the four files with `somnus stamp PATH --write` would let `somnus check --all` cover the whole repository. `AGENTS.md` is a governance file, so stamping it is a deliberate decision rather than routine cleanup.

## Diagnostic housekeeping

Generated Surgeon/Doctor state is git-ignored, not product source. Historical cache counts and encoding observations do not establish this runner's state; do not delete operator-owned history as routine cleanup. `PLAN.md` records a prior Doctor rescan of 371 findings, including 70 serious findings and exit 1, with reviewed dispositions. Passing native gates does not turn that static severity gate green.

## Related pages

- [Pitfalls](background/pitfalls.md)
- [Testing](how-to-contribute/testing.md)
- [Debugging](how-to-contribute/debugging.md)
